# agi

### A Rust library for Artificial General Intelligence.